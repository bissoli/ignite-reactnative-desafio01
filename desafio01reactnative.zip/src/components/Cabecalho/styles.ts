import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create(
    {
       logo: {
         marginTop: 70,
         height: 32,
         width: 110.34,
         alignSelf: 'center'
      }      
   }
);