import { StyleSheet } from 'react-native'

export const styles = StyleSheet.create({
    container: {
        flex: 1,
        fontSize: 14,
        color: '#FFF',
        flexDirection: 'column',
        paddingTop: 0
    }
});